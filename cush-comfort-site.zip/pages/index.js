export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 p-4 sm:p-8">
      <header className="text-center mb-10">
        <div className="flex justify-center mb-4">
          <img src="/logo.jpeg" alt="Cush Comfort Logo" width={150} />
        </div>
        <h1 className="text-4xl sm:text-5xl font-bold mb-2">Cush Comfort Heating & Air Conditioning</h1>
        <p className="text-lg sm:text-xl">Residential & Commercial HVAC | Building Automation & Controls</p>
      </header>

      <section className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 mb-10">
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold mb-2">Residential HVAC</h2>
          <p>Reliable heating and cooling solutions tailored for your home. Comfort and efficiency, year-round.</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold mb-2">Commercial HVAC</h2>
          <p>Custom systems for businesses of all sizes. Keep your employees and customers comfortable and safe.</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold mb-2">Building Automation</h2>
          <p>Integrate HVAC, lighting, and more with intelligent controls. Increase efficiency and reduce operational costs.</p>
        </div>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow-md max-w-2xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4 text-center">Contact Us</h2>
        <form className="grid gap-4">
          <input type="text" placeholder="Your Name" className="p-3 rounded-xl border border-gray-300" />
          <input type="email" placeholder="Your Email" className="p-3 rounded-xl border border-gray-300" />
          <textarea placeholder="Your Message" className="p-3 rounded-xl border border-gray-300" rows="4"></textarea>
          <button type="submit" className="bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition">Send Message</button>
        </form>
      </section>

      <footer className="text-center mt-10 text-sm text-gray-500">
        © {new Date().getFullYear()} Cush Comfort Heating & Air Conditioning. All rights reserved.
      </footer>
    </div>
  )
}